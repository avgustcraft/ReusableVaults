rootProject.name = "ReusableVaults"
